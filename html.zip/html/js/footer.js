document.getElementById("footer").innerHTML = `
<footer>
    <div class="footer-content">
        <div class="ratings">
            <p>★★★★★</p>
            <p>"Ediary has transformed how I manage my tasks!" - User A</p>
            <p>"A must-have for staying organized." - User B</p>
            <p>"Love the seamless sync across devices." - User C</p>
        </div>
        <div class="contact-links">
            <p><a href="contact.html">Contact Us</a></p>
            <p><a href="terms.html">Terms and Conditions</a></p>
        </div>
        <div class="copyright">
            <p>&copy; 2024 Ediary. All rights reserved.</p>
        </div>
    </div>
</footer>
`;
