document.getElementById("header").innerHTML = `
<header>
    <div class="header-left">
        <img src="images/logo.png" alt="Ediary Logo" class="logo">
        <h1>Ediary</h1>
    </div>
    <nav>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="diary.html">Diary</a></li>
            <li><a href="todo.html">To-Do</a></li>
            <li><a href="meetings.html">Meeting Planner</a></li>
        </ul>
    </nav>
</header>
`;
