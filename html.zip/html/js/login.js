document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the traditional way
    // Here you can add code to validate the form and check credentials
    // If the credentials are valid, redirect to the homepage
    window.location.href = 'index.html';
});
